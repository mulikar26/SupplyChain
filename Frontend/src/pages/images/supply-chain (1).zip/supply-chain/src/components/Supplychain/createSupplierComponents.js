import React, { Component } from 'react';

class createSupplierComponents extends Component {
    render() {
        return (
            <div>
                <h1>skdk</h1>
            </div>
        );
    }
}

export default createSupplierComponents;