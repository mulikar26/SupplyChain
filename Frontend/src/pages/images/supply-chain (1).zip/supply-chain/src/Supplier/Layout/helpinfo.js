import React from 'react'

function Helpinfo() {
  return (
   
    <div class="d-flex justify-content-center">
        <div class="text-success">
        <div class="p-3 mb-2 bg-info text-white"> 
        <h1>our team is always Ready to Help<br/>
        
        
        </h1>
        <h2>Contact No= 8888888888 <br/></h2>
        <h3>Email id= 5ASupplychain@gmail.com</h3>
        </div>
       
        
        </div>
    </div>
  )
}

export default Helpinfo