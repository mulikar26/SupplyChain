import React from 'react'

function Teaminfo() {
  return (
    <div class="p-3 mb-2 bg-secondary text-white" >
        <div class="d-flex justify-content-center">
        <h1 ><p class="text-dark">Project Team Members are</p></h1>

        </div>
       
    <div class="d-flex justify-content-center">
    
     
    <br/>
    <h1>Amit Sillarkar 220343420014
       
    <br/>   
    Amit Mulikar 220343420015
    <br/> 
    Anand Patkar 220343420017
    <br/> 
    Atish kamble 220343420023
    <br/> 
    Atul jadhav 220343420025</h1>
       
       <br/>
       
      
       </div>
      
        
      </div>
  )
}

export default Teaminfo